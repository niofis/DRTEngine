#include "Stream.h"

using namespace DRTE;
Stream::~Stream()
{
	
}
