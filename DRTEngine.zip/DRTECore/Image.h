#ifndef _IMAGEHEADER
#define _IMAGEHEADER
//#define byte char
namespace DRTE
{
class Image
{
public:
	int width;
	int height;
	char* data;
};
}
#endif
