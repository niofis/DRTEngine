#ifndef _GLOBALSHEADER
#define _GLOBALSHEADER 

#define Pi 3.14159265
#define RAD 57.29577951		//180/PI
//#define NULL 0

#endif
