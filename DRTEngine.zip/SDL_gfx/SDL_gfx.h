#ifndef _SDL_gfx_SDL_gfx_h_
#define _SDL_gfx_SDL_gfx_h_

//#ifdef PLATFORM_WIN32
#include <SDL/SDL.h>
#include <SDL/SDL_video.h>
//#else
//#include <SDL/SDL.h>
//#include <SDL/SDL_video.h>
//#endif

#endif
